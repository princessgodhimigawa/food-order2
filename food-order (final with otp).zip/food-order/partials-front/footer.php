<!--social-->
<section class="social color-yellow">
        <div class="container text-center">
            <H1>Socials</H1>
            <ul> 
                <li><a href="https://www.facebook.com/Mikaycooks">
                     <div class="s-box">
                         <div class="s-logo">
                             <img src="../food-order/images/facebook.png" alt="" class="img-responsive img-curve">
                         </div>
                         <div class="s-desc">
                            <h4>Contact us on our facebook page</h4>
                         </div>
                     </div> 
                    </a>                                                          
                </li>
                <li><a href="">
                    <div class="s-box">
                        <div class="s-logo">
                            <img src="../food-order/images/foodpanda.png" alt="" class="img-responsive img-curve">
                        </div>
                        <div class="s-desc">
                           <h4>You can also order at Food Panda</h4>
                        </div>
                    </div>
                    </a>
                </li>
            </ul>
            <div class="clearfix"></div>
        </div>
    </section>
    <!--end social-->

    <!--footer-->
    <section class="footer">
        <div class="container text-center">
            <p>All rights reserved</p>
        </div>
    </section>
    <!--end of footer-->

</body>
</html>