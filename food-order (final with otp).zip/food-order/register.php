<?php include('../food-order/config/constants.php')?>

<?php
    if(isset($_POST['verify_number'])){

        $phone = $_POST['contact'];
    $key = '76BE79DEEE044B48996F8341A90EB8EF';
    $default_country = '63';
    $ch = curl_init('https://api.veriphone.io/v2/verify?phone='.$phone.'&key='.$key.'&default_country='.$default_country);  
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    $json = curl_exec($ch);
    curl_close($ch);
    $validationResult = json_decode($json, true);
    echo $validationResult['phone_valid'];
    echo $validationResult['country'];
    echo $validationResult['international_number'];
    echo $validationResult['carrier'];

    if($validationResult['phone_valid'] == 1){
        echo"<p>Inputed # is valid please input it again along with your info!!!.</p>";
    }else{
        echo"<p>Number is Invalid please choose another number</p>";
    }


    }


?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title>Register</title>
    <link rel="stylesheet" href="../food-order/css/style.css">
</head>
<body class="body">
    <!--main content-->
    
    <div class="container1">
        <h1>User</h1>
        
        <?php
            
            if(isset($_SESSION['Exist']))//checking wether the session is set
            {
                echo $_SESSION['Exist'];//display msg
                unset($_SESSION['Exist']);//display msg
            }
            if(isset($_SESSION['contact']))//checking wether the session is set
            {
                echo $_SESSION['contact'];//display msg
                unset($_SESSION['contact']);//display msg
            }
        ?>
            <!--login form-->

        <form action="" method="post">

            <div class="tbox">
            <input type="text" name="contact"  placeholder="Enter Valid Contact!!!">
            </div>
            <div class="">
            <input type="submit" name="verify_number" value=" click to check/Verify # first" class="btn1">
            </div>
            <div class="tbox">
            <input type="text" name="full_name" placeholder="Enter your Name">
            </div>
            <div class="tbox">
            <input type="text" name="username" placeholder="Enter Username">
            </div>
            <div class="tbox">
            <input type="password" name="password" placeholder="Enter Password">
            </div>
            <div class="tbox">
            <input type="EMAIL" name="email" placeholder="Enter your email">
            </div>
            <div class="tbox">
            <input type="text" name="address" rows="5" placeholder="E.g. Drive, Street, Barangay">
            </div>

            
            <input type="submit" name="submit" value="Register" class="btn1">
              
        </form>
         
    </div>
<?php
    
    

    //process the value from form & save in database
    //check whether button is click/not
    if(isset($_POST['submit']))
{
        //button clicked
       // echo"button click";
       //check if user exist
       $sql3 = "SELECT * FROM tbl_user WHERE user = '".$_POST['username']."'";
       
       $select = mysqli_query($conn, $sql3);
        if(mysqli_num_rows($select)) 
        {
            $_SESSION['Exist'] = "<div class='error'>User already Exist.</div>";
            //redirect page to add admin
            header("location:".SITEURL.'../food-order/register.php');
        }else
        {
           //get data from form
        $full_name = $_POST['full_name'];
        $contact = $_POST['contact'];
        $username = $_POST['username'];
        $password = md5($_POST['password']); //password encryption md5
        $address = $_POST['address'];
        $email = $_POST['email'];

        $vkey = (rand(100000, 999999).$username);
        
        



            // SQL query to save to database
            $sql = "INSERT INTO tbl_user SET
                user_name = '$full_name',  
                contact = '$contact',
                user = '$username',
                pass = '$password',
                address = '$address',
                email = '$email',
                vkey = '$vkey'

               
            ";
            
            // executing query and save data to database
            $res = mysqli_query($conn, $sql) or die(mysqli_error());

            //check whether the data is inserted or not
            if($res==TRUE)
            {
                //data inserted 
                //echo "data inserted"
                //create a session variable to display message
                $_SESSION['add'] = "<div class='success'>User Added Successfully.</div>";
                //redirect page to manage admin
                header("location:".SITEURL.'../food-order/login.php');
                
            }
            else
            {
                //failed to insert data
                //echo"fail, data not inserted";
                //create a session variable to display message
                $_SESSION['add'] = "<div class='error'>Failed to Add User.</div>";
                //redirect page to add admin
                header("location:".SITEURL.'../food-order/register.php');
            }
        }

}

    

?>
    <!--end main content-->

    
</body>
</html>

