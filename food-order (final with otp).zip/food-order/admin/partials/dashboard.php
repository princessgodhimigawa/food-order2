<?php 
    include('../config/constants.php');
    include('login-check.php');
?>