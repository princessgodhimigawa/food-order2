<!--footer-->
<div class="footer">
        <div class="wrapper">
                <p class="text-center">all rights reserved. Mikay's Kitchen</p>
            </div>
        </div>
        <!--end of footer -->

    </body>
    
</html>